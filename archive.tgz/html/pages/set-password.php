<?php
session_start();

$token = (string) ($_GET['token'] ?? ($_SESSION['verified_invite_token'] ?? ''));

$accountCreatedDetails = $_SESSION['account_created_details'] ?? null;

$showAccountCreated = is_array($accountCreatedDetails);

$mailConfig = require __DIR__ . '/../config/mail.php';

$testingConfig = require __DIR__ . '/../config/testing.php';

$useDummyValues = (bool) ($testingConfig['use_dummy_values'] ?? false);

$dummyPassword = (string) ($testingConfig['dummy_password'] ?? 'Test@12345');

$googlePlayLink = (string) ($mailConfig['google_play_link'] ?? 'https://play.google.com/store');

$appStoreLink = (string) ($mailConfig['app_store_link'] ?? 'https://www.apple.com/app-store/');

$googlePlayImagePath = __DIR__ . '/assets/Photos/googlePlay.png';

$appStoreImagePath = __DIR__ . '/assets/Photos/Apple store.png';

if ($accountCreatedDetails !== null) {
    unset($_SESSION['account_created_details']);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Set Password</title>

<link rel="icon" type="image/x-icon" href="/assets/Photos/favicon.ico">

<link rel="preconnect" href="https://fonts.googleapis.com">

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: 'Inter', 'Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', sans-serif;
}
.password-rules li{
    font-family: 'Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', sans-serif;
}
body{
    background:#f5f7f9;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    padding:20px;
}
.password-rules ul{
    list-style:none;
    padding:0;
    margin:0;
}

.password-rules li{
    display:flex;
    align-items:center;
    gap:8px;
    margin:10px 0;
    color:#64748b;
    font-size:14px;
    transition:.3s;
}

.password-rules li.valid{
    color:#16a34a;
    font-weight:600;
}

.password-rules li.invalid{
    color:#ef4444;
}
.container{
    width:100%;
    max-width:500px;
}

.card{
    background:#ffffff;
    border-radius:24px;
    padding:40px;
    box-shadow:0 4px 20px rgba(0,0,0,0.05);
}

.logo{
    display:flex;
    align-items:center;
    gap:10px;
    margin-bottom:25px;
}

.logo-box{
    width:52px;
    height:52px;
    border-radius:16px;
    background:#ecfdf5;
    border:1px solid #d1fae5;
    box-shadow:0 10px 24px rgba(74,222,128,0.18);
    display:flex;
    align-items:center;
    justify-content:center;
    padding:8px;
}

.logo-box img{
    width:100%;
    height:100%;
    object-fit:contain;
}

.logo h1{
    font-size:24px;
    color:#0f172a;
    font-weight:700;
}

.title{
    font-size:30px;
    font-weight:700;
    color:#0f172a;
    margin-bottom:8px;
}

.title span{
    color:#4ade80;
}

.subtitle{
    color:#64748b;
    margin-bottom:30px;
    font-size:15px;
}

.form-group{
    margin-bottom:22px;
    position:relative;
}

label{
    display:block;
    margin-bottom:8px;
    color:#0f172a;
    font-weight:500;
}

input{
    width:100%;
    padding:14px 50px 14px 16px;
    border:1px solid #e2e8f0;
    border-radius:14px;
    outline:none;
    font-size:15px;
    transition:0.3s;
}

input:focus{
    border-color:#4ade80;
    box-shadow:0 0 0 4px rgba(74,222,128,0.15);
}

.input-error{
    border-color:#ef4444 !important;
}

.password-toggle{
    position:absolute;
    right:16px;
    top:42px;
    display:flex;
    align-items:center;
    justify-content:center;
    width:24px;
    height:24px;
    padding:0;
    border:none;
    background:transparent;
    cursor:pointer;
    color:#64748b;
}

.password-toggle:hover{
    color:#0f172a;
}

.password-toggle:focus{
    outline:none;
    color:#0f172a;
}

.password-toggle svg{
    width:20px;
    height:20px;
    stroke:currentColor;
}

.password-rules{
    background:#f8fafc;
    border:1px solid #e2e8f0;
    border-radius:16px;
    padding:18px;
    margin-bottom:24px;
}

.password-rules{
    transition: opacity .25s ease, transform .25s ease;
}

.password-rules.is-hidden{
    opacity:0;
    transform:translateY(-8px);
    visibility:hidden;
    height:0;
    padding:0;
    margin:0;
    overflow:hidden;
    border:none;
}

.password-rules h3{
    font-size:16px;
    margin-bottom:12px;
    color:#0f172a;
}

.password-rules ul{
    margin:0;
    padding-left:18px;
}

.password-rules li{
    color:#64748b;
    margin-bottom:8px;
    font-size:14px;
}

.password-rules li:last-child{
    margin-bottom:0;
}

.testing-password{
    background:#f8fafc;
    border:1px dashed #86efac;
    border-radius:16px;
    padding:16px;
    margin-bottom:22px;
}

.testing-password p{
    color:#475569;
    font-size:14px;
    margin-bottom:12px;
}

.testing-password strong{
    color:#0f172a;
}

.testing-password button{
    padding:11px 14px;
    border-radius:12px;
    font-size:14px;
}

.password-strength{
    margin-top:10px;
    font-size:14px;
    font-weight:600;
}

.match-message{
    margin-top:10px;
    font-size:14px;
    font-weight:600;
}

.loader{
    width:22px;
    height:22px;
    border:3px solid rgba(255,255,255,0.3);
    border-top-color:#ffffff;
    border-radius:50%;
    animation:spin 1s linear infinite;
    display:none;
    margin:auto;
}

@keyframes spin{
    to{
        transform:rotate(360deg);
    }
}

button{
    width:100%;
    padding:15px;
    border:none;
    border-radius:14px;
    background:#4ade80;
    color:white;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    background:#22c55e;
}

button:disabled{
    opacity:0.7;
    cursor:not-allowed;
}

.success-box{
    background:#dcfce7;
    border:1px solid #86efac;
    border-radius:18px;
    padding:22px;
    margin-bottom:24px;
    text-align:center;
}

.success-icon{
    font-size:50px;
    margin-bottom:14px;
}

.success-box h3{
    color:#15803d;
    margin-bottom:16px;
}

.success-box p{
    margin-bottom:10px;
    color:#166534;
}

.download-section{
    margin-top:24px;
    text-align:center;
}

.download-section h3{
    margin-bottom:18px;
    color:#0f172a;
}

.download-links a{
    display:inline-block;
    margin:8px;
    vertical-align:middle;
}

.download-links img{
    width:190px;
    height:62px;
    max-width:100%;
    object-fit:contain;
    border:0;
    display:block;
}

.app-store-btn{
    display:inline-block;
    padding:14px 24px;
    background:#0f172a;
    color:white;
    border-radius:14px;
    text-decoration:none;
    font-weight:500;
}

.footer{
    text-align:center;
    margin-top:24px;
    color:#94a3b8;
    font-size:14px;
}

.toast{
    position:fixed;
    top:30px;
    left:50%;
    transform:translateX(-50%);
    color:#ffffff;
    padding:14px 22px;
    border-radius:12px;
    font-size:14px;
    font-weight:600;
    box-shadow:0 8px 20px rgba(0,0,0,0.15);
    z-index:9999;
    opacity:0;
    transition:0.3s;
}
#createAccountBtn{
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.btn-loader{
    width:18px;
    height:18px;
    border:2px solid rgba(255,255,255,0.4);
    border-top:2px solid #fff;
    border-radius:50%;
    animation:spin 1s linear infinite;
    display:none;
}


</style>

</head>

<body>

<div class="container">

    <div class="card">

        <div class="logo">

            <div class="logo-box">
                <img src="/assets/Photos/icon-192.png" alt="Drivault logo">
            </div>

            <h1>Drivault</h1>

        </div>

        <?php if (!$showAccountCreated) { ?>

        <h2 class="title">
            Create <span>Password</span>
        </h2>

        <p class="subtitle">
            Set a secure password to complete your account setup.
        </p>

        <?php if ($useDummyValues) { ?>

        <div class="testing-password">
            <p>
                Testing Password : <strong id="testingPassword"><?php echo htmlspecialchars($dummyPassword, ENT_QUOTES, 'UTF-8'); ?></strong>
            </p>

            <button
                type="button"
                onclick="useTestingPassword()"
            >
                Use Testing Password
            </button>
        </div>

        <?php } ?>

        <form
            id="set-password-form"
            action="../api/set_password.php"
            method="POST"
        >

       <input
    type="hidden"
    name="token"
    value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>"
>

<!-- Username -->

<div class="form-group">

    <label for="username">
        Username
    </label>

    <input
    id="username"
    type="text"
    name="username"
    placeholder="Choose a username"
    minlength="6"
    maxlength="20"
    required
>
<div
    class="match-message"
    id="usernameMessage"
></div>
</div>

<!-- Password -->

<div class="form-group">

    <label for="password">
        Password
    </label>

                <input
                    id="password"
                    type="password"
                    name="password"
                    autocomplete="new-password"
                    placeholder="Enter password"
                    required
                >

                <button
                    type="button"
                    class="password-toggle"
                    onclick="togglePassword('password', this)"
                    aria-label="Show password"
                    title="Show password"
                >
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
                        <circle cx="12" cy="12" r="3" stroke-width="1.8"></circle>
                    </svg>
                </button>

                <div
                    class="password-strength"
                    id="passwordStrength"
                ></div>

            </div>

            <div class="form-group">

                <label for="confirm_password">
                    Confirm Password
                </label>

                <input
                    id="confirm_password"
                    type="password"
                    name="confirm_password"
                    autocomplete="new-password"
                    placeholder="Confirm password"
                    required
                >

                <button
                    type="button"
                    class="password-toggle"
                    onclick="togglePassword('confirm_password', this)"
                    aria-label="Show password"
                    title="Show password"
                >
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
                        <circle cx="12" cy="12" r="3" stroke-width="1.8"></circle>
                    </svg>
                </button>

                <div
                    class="match-message"
                    id="matchMessage"
                ></div>

            </div>

            <div class="password-rules is-hidden" id="passwordRules">

    <h3>Password Requirements</h3>

    <ul>
        <li id="rule-length">❌ Minimum 10 characters</li>
        <li id="rule-upper">❌ At least 1 uppercase letter</li>
        <li id="rule-lower">❌ At least 1 lowercase letter</li>
        <li id="rule-number">❌ At least 1 number</li>
        <li id="rule-special">❌ At least 1 special character</li>
    </ul>

</div>

            <button id="createAccountBtn" type="submit">
    <span id="btnText">Create Account</span>
    <span id="btnLoader" class="btn-loader"></span>
</button>

            <div
                class="loader"
                id="loader"
            ></div>

        </form>

        <?php } ?>

        <?php if ($showAccountCreated) { ?>

        <div class="success-box">

            <div class="success-icon">
                &#10003;
            </div>

            <h3>
                Congratulations! 
            </h3>

            <p>
Your username and password have been set successfully. Your Drivault account is now ready to use.            </p>
        
        </div>

        <div class="download-section">

            <h3>
                Download App
            </h3>

            <div class="download-links">

    <a href="<?php echo htmlspecialchars($googlePlayLink, ENT_QUOTES, 'UTF-8'); ?>"
       target="_blank"
       rel="noopener noreferrer">
        <img
            src="/assets/Photos/googlePlay.png"
            alt="Get it on Google Play"
            style="width:190px;height:auto;"
        >
    </a>

    <a href="<?php echo htmlspecialchars($appStoreLink, ENT_QUOTES, 'UTF-8'); ?>"
       target="_blank"
       rel="noopener noreferrer">
        <img
            src="/assets/Photos/Apple store.png"
            alt="Download on the App Store"
            style="width:190px;height:auto;"
        >
    </a>

</div>

        </div>

        <?php } ?>

        <div class="footer">
            &#169; 2026 Drivault
        </div>

    </div>

</div>

<script>

function showToast(message, type = 'success') {

    const toast = document.createElement('div');

    toast.className = 'toast';

    toast.innerText = message;

    if(type === 'error') {

        toast.style.background = '#ef4444';

    } else {

        toast.style.background = '#22c55e';
    }

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '1';
    }, 100);

    setTimeout(() => {

        toast.style.opacity = '0';

        setTimeout(() => {
            toast.remove();
        }, 300);

    }, 3000);
}

function togglePassword(inputId, element) {

    const input = document.getElementById(inputId);

    const showIcon = `
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
            <circle cx="12" cy="12" r="3" stroke-width="1.8"></circle>
        </svg>
    `;

    const hideIcon = `
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M3 3l18 18" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
            <path d="M10.6 5.1A11.7 11.7 0 0 1 12 5c6.5 0 10 7 10 7a17.6 17.6 0 0 1-3.2 4.2" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
            <path d="M6.7 6.7C3.9 8.5 2 12 2 12a17.8 17.8 0 0 0 10 7 9.7 9.7 0 0 0 4-.8" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
            <path d="M9.9 9.9A3 3 0 0 0 14.1 14.1" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
    `;

    if(input.type === 'password') {

        input.type = 'text';

        element.innerHTML = hideIcon;
        element.setAttribute('aria-label', 'Hide password');
        element.setAttribute('title', 'Hide password');

    } else {

        input.type = 'password';

        element.innerHTML = showIcon;
        element.setAttribute('aria-label', 'Show password');
        element.setAttribute('title', 'Show password');
    }
}

const usernameInput = document.getElementById('username');
const usernameMessage = document.getElementById('usernameMessage');
let usernameTimer = null;
let usernameAvailable = false;

const passwordInput = document.getElementById('password');

const confirmPasswordInput = document.getElementById('confirm_password');

const passwordStrength = document.getElementById('passwordStrength');

const matchMessage = document.getElementById('matchMessage');

const passwordRules = document.getElementById('passwordRules');
const ruleLength = document.getElementById("rule-length");
const ruleUpper = document.getElementById("rule-upper");
const ruleLower = document.getElementById("rule-lower");
const ruleNumber = document.getElementById("rule-number");
const ruleSpecial = document.getElementById("rule-special");

const form = document.getElementById('set-password-form');

const loader = document.getElementById('loader');

const createAccountBtn = document.getElementById('createAccountBtn');
const btnText = document.getElementById('btnText');
const btnLoader = document.getElementById('btnLoader');

function useTestingPassword() {

    const testingPassword = document.getElementById('testingPassword')?.innerText || '';

    if(!testingPassword || !passwordInput || !confirmPasswordInput) {
        return;
    }

    passwordInput.value = testingPassword;
    confirmPasswordInput.value = testingPassword;
    passwordInput.classList.remove('input-error');
    confirmPasswordInput.classList.remove('input-error');
    checkPasswordStrength(testingPassword);
    validatePasswordMatch();
    togglePasswordRules(false);
}

function checkPasswordStrength(password){

    if(password.length === 0){

        togglePasswordRules(false);

        ruleLength.style.display = "flex";
        ruleUpper.style.display = "flex";
        ruleLower.style.display = "flex";
        ruleNumber.style.display = "flex";
        ruleSpecial.style.display = "flex";

        return;
    }

    const hasLength = password.length >= 10;
    const hasUpper = /[A-Z]/.test(password);
    const hasLower = /[a-z]/.test(password);
    const hasNumber = /\d/.test(password);
    const hasSpecial = /[^A-Za-z0-9]/.test(password);

    updateRule(ruleLength, hasLength);
    updateRule(ruleUpper, hasUpper);
    updateRule(ruleLower, hasLower);
    updateRule(ruleNumber, hasNumber);
    updateRule(ruleSpecial, hasSpecial);

    if(hasLength && hasUpper && hasLower && hasNumber && hasSpecial){

        // Hide the entire Password Requirements box
        togglePasswordRules(false);

    }else{

        togglePasswordRules(true);

    }

    passwordStrength.innerHTML = "";

}
// function checkPasswordStrength(password) {

//     if (password.length === 0) {

//         passwordStrength.innerHTML = '';
//         return;
//     }

//     if (password.length < 10) {

//         passwordStrength.innerHTML =
//             '? Password must be at least 10 characters';

//         passwordStrength.style.color = '#ef4444';

//     } else {

//         passwordStrength.innerHTML =
//             '? Minimum 10 characters completed';

//         passwordStrength.style.color = '#22c55e';
//     }
// }

function isPasswordValid(password) {
    return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{10,}$/.test(password);
}

function togglePasswordRules(showRules) {

    if(!passwordRules) {
        return;
    }

    passwordRules.classList.toggle('is-hidden', !showRules);
}

function updateRule(element, valid){

    if(valid){
        element.style.display = "none";
    }else{
        element.style.display = "flex";
    }

}
passwordInput?.addEventListener("input", function(){

    checkPasswordStrength(this.value);

    validatePasswordMatch();

});
// passwordInput?.addEventListener('input', () => {

//     checkPasswordStrength(passwordInput.value);

//     if(passwordInput.value === '' || isPasswordValid(passwordInput.value)) {
//         togglePasswordRules(false);
//         passwordInput.classList.remove('input-error');
//     }

//     validatePasswordMatch();
// });

confirmPasswordInput?.addEventListener('input', () => {
    validatePasswordMatch();
});
// usernameInput?.addEventListener('input', validateUsername);
//confirmPasswordInput.addEventListener('input', validatePasswordMatch);

function validatePasswordMatch() {

   const password = passwordInput.value;
    const confirmPassword = confirmPasswordInput.value;

    if (confirmPassword === '') {
        matchMessage.innerHTML = '';
        confirmPasswordInput.classList.remove('input-error');
        return;
    }

    if (password === confirmPassword) {

        matchMessage.innerHTML = '';
        matchMessage.style.color = '#22c55e';

        confirmPasswordInput.classList.remove('input-error');

    } else {

        matchMessage.innerHTML = ' Passwords Do Not Match';
        matchMessage.style.color = '#ef4444';

        confirmPasswordInput.classList.add('input-error');
    }
}

function validateUsername() {

    const username = usernameInput.value.trim();

    if (username.length === 0) {

        usernameMessage.innerHTML = '';
        usernameInput.classList.remove('input-error');
        return false;
    }

    if (username.length < 6) {

        usernameMessage.innerHTML =
            'Username must be at least 6 characters';

        usernameMessage.style.color = '#ef4444';

        usernameInput.classList.add('input-error');

        return false;
    }

    // usernameMessage.innerHTML = '';
    usernameInput.classList.remove('input-error');

    return true;
}
usernameInput.addEventListener('input', function () {

    clearTimeout(usernameTimer);

    usernameAvailable = false;

    const username = this.value.trim();

    if (username.length === 0) {

    usernameMessage.innerHTML = '';
    usernameInput.classList.remove('input-error');
    return;
}

if (username.length < 6) {

    usernameAvailable = false;

    usernameMessage.innerHTML =
        'Username must be at least 6 characters';

    usernameMessage.style.color = '#ef4444';

    usernameInput.classList.add('input-error');

    return;
}

usernameInput.classList.remove('input-error');

    usernameMessage.innerHTML = 'Checking username availability...';
    usernameMessage.style.color = '#666';

    usernameTimer = setTimeout(async () => {

        try {

            const response = await fetch("../api/verify-drivault-user.php?username=" + encodeURIComponent(username));

            const data = await response.json();

            if (data.available) {

                usernameAvailable = true;

                usernameMessage.innerHTML = 'This username is available.';
                usernameMessage.style.color = '#16a34a';

            } else {

                usernameAvailable = false;

                usernameMessage.innerHTML = 'This username is unavailable. ';
                usernameMessage.style.color = '#ef4444';

            }

        } catch (e) {

            usernameAvailable = false;

            usernameMessage.innerHTML = 'Connection error';
            usernameMessage.style.color = '#ef4444';

        }

    }, 500);

});
form?.addEventListener('submit', async function(event) {

    event.preventDefault();
   if (!validateUsername() || !usernameAvailable) {

    showToast(
        'Please choose an available username.',
        'error'
    );

    return;
}

    const password = passwordInput.value;

    const confirmPassword = confirmPasswordInput.value;

    if(!isPasswordValid(password)) {

        togglePasswordRules(true);
        passwordInput.classList.add('input-error');

        showToast(
    'Password must be at least 10 characters and contain uppercase, lowercase, number and special character',
    'error'
);

        return;
    }

    if(password !== confirmPassword) {

    matchMessage.innerHTML = 'Passwords Do Not Match';
    matchMessage.style.color = '#ef4444';
    confirmPasswordInput.classList.add('input-error');

    return;
}

   createAccountBtn.disabled = true;

btnText.textContent = 'Creating Account...';

btnLoader.style.display = 'inline-block';

    showToast('Creating Account...');

    try {

        const formData = new FormData(form);
        formData.append('response_type', 'json');

        const response = await fetch(form.action, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
        });

        if(!response.ok) {
            const message = (await response.text()).trim();
            showToast(message || 'Unable to create account.', 'error');
           createAccountBtn.disabled = false;

btnText.textContent = 'Create Account';

btnLoader.style.display = 'none';
            return;
        }

        const result = await response.json();

        showToast(result.message || 'Account created successfully.');

        if(result.redirect) {
            window.location.href = result.redirect;
        }

    } catch (error) {

        showToast('Unable to create account. Please try again.', 'error');
        createAccountBtn.disabled = false;
        createAccountBtn.style.display = 'block';
        loader.style.display = 'none';
    }

});

</script>

</body>

</html><?php
