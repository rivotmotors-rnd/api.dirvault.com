<?php
declare(strict_types=1);

$appConfig = require __DIR__ . '/app.php';

return [
    'host' => getenv('SMTP_HOST') ?: 'smtp.hostinger.com',
    'port' => (int) (getenv('SMTP_PORT') ?: 465),
    'encryption' => getenv('SMTP_ENCRYPTION') ?: 'ssl',

    'username' => getenv('SMTP_USERNAME') ?: 'contacts@drivault.com',
    'password' => getenv('SMTP_PASSWORD') ?: 'C5p48xm>y',

    'from_address' => getenv('SMTP_FROM_ADDRESS') ?: 'contacts@drivault.com',
    'from_name' => getenv('SMTP_FROM_NAME') ?: 'Drivault',

    'inviter_name' => getenv('SMTP_INVITER_NAME') ?: 'Drivault',

    'website_url' => getenv('WEBSITE_URL') ?: $appConfig['base_url'],
    'support_email' => getenv('SUPPORT_EMAIL') ?: 'support@drivault.com',

    'google_play_link' => getenv('GOOGLE_PLAY_LINK')
        ?: 'https://play.google.com/store/search?q=Drivault&c=apps',

    'app_store_link' => getenv('APP_STORE_LINK')
        ?: 'https://www.apple.com/in/search/drivault?src=globalnav',
];
